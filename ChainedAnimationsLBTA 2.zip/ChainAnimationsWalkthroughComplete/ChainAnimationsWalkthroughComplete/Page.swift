//
//  Page.swift
//  LessonPlanner
//
//  Created by Brian Voong on 3/27/18.
//  Copyright © 2018 Brian Voong. All rights reserved.
//

import Foundation

struct Page {
    let title: String
    let body: String
}

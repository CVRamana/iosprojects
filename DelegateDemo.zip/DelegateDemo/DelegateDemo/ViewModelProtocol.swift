//
//  ViewModelProtocol.swift
//  DelegateDemo
//
//  Created by Deepak Saxena on 28/08/19.
//  Copyright © 2019 Deepak Saxena. All rights reserved.
//

import Foundation



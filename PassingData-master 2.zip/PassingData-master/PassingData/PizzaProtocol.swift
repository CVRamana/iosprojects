//
//  PizzaProtocol.swift
//  PassingData
//
//  Created by Reinder de Vries on 15/07/2017.
//  Copyright © 2017 LearnAppMaking. All rights reserved.
//

import Foundation

protocol PizzaDelegate
{
    func onPizzaReady(type: String)
}

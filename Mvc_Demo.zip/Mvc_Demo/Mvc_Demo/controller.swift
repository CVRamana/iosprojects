//
//  View.swift
//  Mvc_Demo
//
//  Created by Admin on 28/08/19.
//  Copyright © 2019 Appinventiv. All rights reserved.
//

import Foundation
let p1=Person(name: "Raman",age: 23)
let address=Address(street:"club-15", House_No:101)
let pinfo=p1.personInfo()
let Ainfo=address.AdressInfo()
